class ipconfig {
    //static url: string = '192.168.68.59';deedperu
    static url: string = '192.168.0.19:3001';
  }
  
  export default ipconfig;