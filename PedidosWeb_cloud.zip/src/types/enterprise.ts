class enterprise {
    static ruc: string = '20556936685';
    static razon: string = 'DISTRIBUIDORA Y COMERCIAL LISAORE EIRL'
  }
  
  export default enterprise;