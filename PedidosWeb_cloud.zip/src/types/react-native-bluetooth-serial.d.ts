declare module 'xxx-bluetooth-serial';
