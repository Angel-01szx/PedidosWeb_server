import React from 'react';
import S from './ConsultScreen.styles';

export default function ConsultScreen() {
  return (
    <S.Container>
      <p>Pantalla de Consultas</p>
    </S.Container>
  );
}
